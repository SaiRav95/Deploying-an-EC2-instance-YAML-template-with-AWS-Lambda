import json
import yaml
import boto3

def lambda_handler(event, context):
        
        region = 'us-west-1'
            
                try:
                            
                            s3 = boto3.client('s3')
                                    bucket = event['Records'][0]['s3']['bucket']['name']
                                            key = event['Records'][0]['s3']['object']['key']
                                                    
                                                            print('Bucket: ', bucket, 'Key: ', key)
                                                                
                                                                    except Exception as e:
                                                                                
                                                                                print(str(e))
